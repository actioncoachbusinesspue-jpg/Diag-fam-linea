# Evidencia de la versión 1.0.2.2

- `logs/` — salida completa de cada suite: E2E (ambas estructuras de
  despliegue), integración, MySQL/MariaDB real, paridad y health-check.
- `screenshots/` — capturas generadas por `tests/e2e/browser_v1022.mjs`:
  panel de invitación de la portada, cupo lleno, Borrador sin formulario y el
  aviso de privacidad en 1280×840, 390×844 y 375×667.
- `reportes/` — los 8 PDF de regresión (demo, real, estrés y empates × Carta y
  A4), auditados con 12 páginas cada uno, y sus hojas de contacto.
- `paridad/` — objeto familia generado desde la base de datos y reporte de
  paridad numérica (diferencia 0).
- `CONGELAMIENTO_HASHES.md` — SHA-256 del motor metodológico al abrir y al
  cerrar la versión.

No se incluyen los PNG página por página (`qa-evidence/png/`, ~25 MB) porque
se regeneran con `bash tests/evidence/run_evidence.sh`. Las hojas de contacto
de `reportes/` cumplen la misma función de revisión visual.

Esta carpeta no contiene datos de clientes: todas las familias son ficticias
(Familia Horizonte, familias QA y familias de estrés generadas por las suites).
